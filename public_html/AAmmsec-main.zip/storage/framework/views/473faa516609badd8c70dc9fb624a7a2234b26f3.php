<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(URL::to('assets/home/css/bootstrap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::to('assets/home/css/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::to('assets/home/css/custom.css')); ?>" rel="stylesheet" />
       
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:200,700,800" rel="stylesheet">
    <style type="text/css">
        body {
        font-family: avenir-lt-w01_35-light1475496;
        font-weight: 400;
        }
        section {
     padding: 10px 0; 
    overflow-x: hidden;
}
    </style>
    <?php echo $__env->yieldContent('styles'); ?>

</head>
<body>
    <div class="page-holder">
     
        <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
      
     
        <?php echo $__env->yieldContent('contents'); ?> 
        
        
        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div> 
    <script src="<?php echo e(URL::to('assets/home/js/bootjs.js')); ?>"></script>
    <script src="<?php echo e(URL::to('assets/home/js/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('assets/home/js/jquery.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>

                            
    
</body>
</html><?php /**PATH C:\xampp\htdocs\deepak\AAmmsec-main\resources\views/layouts/site.blade.php ENDPATH**/ ?>