
<nav class="navbar main-navigation navbar-fixed-top has-shadow">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href=""><img src="/assets/admin/images/finallogo.png" alt="logo"></a>
      </div>
      <div class="collapse navbar-collapse" id="navbar">
        <ul class="nav navbar-nav navbar-right">
          <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($menu->has_menu_subitems==0): ?>
              <li><a href="<?php echo e(route( 'showPage',['PageId'=>$menu->id,'slug'=>$menu->slug])); ?>" ><?php echo e($menu->menu_item_name); ?></a></li>
            <?php else: ?>
              <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo e($menu->menu_item_name); ?><span class="caret"></span></a>
                <ul class="dropdown-menu">
                   <?php $__currentLoopData = $submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($submenu->menu_item_id==$menu->id): ?>
                        <li><a href="<?php echo e(route( 'showSubPage',['subPageId'=>$submenu->id,'slug'=>$submenu->slug])); ?>"><?php echo e($submenu->submenu_item_name); ?></a></li>
                       
                      <?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  </ul>
                </li>
            <?php endif; ?>            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <!-- <li><a href="home" >Home</a></li>
          
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">IT Services<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="/it-services">Managed IT Services</a></li>
              <li><a href="/remote-support">Remote Support</a></li>
              <li><a href="/project-management">Project Management</a></li>
              <li><a href="/infrastructure-management">Infrastructure Management</a></li>
              <li><a href="/it-strategy">IT Strategy</a></li>
            </ul>
          </li>
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Cyber Security<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="managed-security-services">Managed Security Services</a></li>
              <li><a href="cyber-incident-recovery">Cyber Incident Recovery</a></li>
              <li><a href="it-dos-donts">Do's &amp; Don'ts</a></li>
            </ul>
          </li>
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Cloud Services<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="home/cloud_services/cloud-based-multi-factor-authentication">Cloud Based Multi-factor Authentication</a></li>
              <li><a href="home/cloud_services/cloud-services-based-on-security-service">Cloud Services based on security service</a></li>
            </ul>
          </li>
         <li><a href="home/products" >Products</a></li> 
        <li><a href="home/support" >Support</a></li>-->       
                 
          
              <?php if(Auth::user()): ?>
              <li><a href="#"></a></li>
              <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-user style="margin-right:5px;"></i>  Hi <?php echo e(explode(' ',Auth::user()->user_name)[0]); ?><span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href=<?php echo e(route('user.dashboard')); ?>>Dashboard</a></li>
                  <li><a  href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                    <i data-feather="log-out" class="icon"></i>
                    LogOut
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                </ul>
              </li>
          
              <?php else: ?>             
              
          
                <li><a href="<?php echo e(route('login')); ?>"  class="btn btn-default btn-outline btn-circle" >Login</a></li>
            <?php endif; ?>
          
        </ul>
      </div>
    </div>
  </nav>
<?php /**PATH C:\xampp\htdocs\deepak\AAmmsec-main\resources\views/partials/header.blade.php ENDPATH**/ ?>