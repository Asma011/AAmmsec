<?php $__env->startSection('styles'); ?>
<style type="text/css">
	.img-circle {
		width: 150px;
		height: 150px;
	}
	.inner-box {
		cursor: pointer;
	}.moving-bg {
		background: url(/assets/uploads/banners/cd4be3cde8c79f45cd5d67b785e4496b.jpg) !important;;
	}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
<div id="home" class="header-1 demo-1 has-gradient">
	<div class="moving-bg"></div>
	<div class="container">
		<div class="header-1-content row">
			<div class="col-md-9 col-sm-12">
				<h1 class="has-line">Aammsecurities</h1>
				<p class="lead">Revolutionize the way you secure the data, resources, and users in your network with aammsecurities</p>
			</div>
		</div>
	</div>
</div>
<?php echo $__env->make('partials.quiz', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="about" class="about">
	<div class="container">
		<div class="row">
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
			<?php echo $content['description']; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepak\AAmmsec-main\resources\views/index.blade.php ENDPATH**/ ?>