

   
   <!-- ======================================= 
        ==Start footer section==  
        =======================================-->
        <footer class="main-footer footer-style-two text-center">          
             <!--Footer Bottom-->
              <div class="footer-bottom">
                 <div class="auto-container">
                    <div class="copyright-text">Copyright © 2021 AAMMSECURITIES. All Rights Reserved <a href=""></a></div>
                 </div>
              </div>
            </footer>
            <!-- ======================================= 
            ==End footer section==  
            =======================================-->
    
    
            <!-- ======================================= 
            ==Start preloader section==  
            =======================================-->
            <section class="preloader">
              <div class="loader">
                    <div class="loader-inner"></div>
                </div>
            </section>
            <!-- ======================================= 
            ==End preloader section==  
            =======================================-->
<?php /**PATH C:\xampp\htdocs\deepak\AAmmsec-main\resources\views/partials/footer.blade.php ENDPATH**/ ?>