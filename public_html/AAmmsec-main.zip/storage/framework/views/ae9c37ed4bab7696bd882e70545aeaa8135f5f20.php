<?php $__env->startSection('title'); ?>
   
<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($page->page_title); ?>

        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style type="text/css">
        .img-circle {
            width: 150px;
            height: 150px;
        }
        .inner-box {
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="home" class="header-1 demo-1 has-gradient">
	<div class="moving-bg" style="background:url(<?php echo e(asset('/assets/uploads/banners/'.$page->banner_img_location)); ?>)!important"></div>
	<div class="container">
		<div class="header-1-content row">
			<div class="col-md-9 col-sm-12">
				<h1 class="has-line"> <?php echo e($page->banner_title); ?></h1>
				<p class="lead"><?php echo e($page->banner_sub_title); ?></p>
			</div>
		</div>
	</div>
</div>
<?php echo $__env->make('partials.quiz', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="services" class="how-it-work">
    <div class="container">
      <div class="how-one-container" >
        <div class="row" style="padding: 60px">
            <?php echo $page->Section_Content1; ?>

        </div>
      </div>
      <div class="how-one-container" >
        <div class="row" style="background: #ebeaea; padding: 60px">
            <?php echo $page->Section_Content2; ?>

        </div>
      </div>
      <div class="how-one-container" style="padding: 60px">
        <div class="row">
            <?php echo $page->Section_Content3; ?>

        </div>
      </div>
    </div>
  </section>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deepak\AAmmsec-main\resources\views/page-template.blade.php ENDPATH**/ ?>