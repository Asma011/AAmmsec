/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  https://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_4993 = ["use strict", "load", "width", "animate", ".loader-bar", "Cancel", "btn-xs btn-inverse", "bottom", "right", "animated fadeInRight", "animated fadeOutRight", "growl", "Welcome to MyDiscounter Admin", "inverse", "slow", "fadeOut", ".loader-bg", "on", "click", "slideToggle", ".extra-profile-list", ".designation", "height", "#1b8bf9", "slimScroll", ".main-friend-list ", "keyup", "toLowerCase", "val", "text", "indexOf", "show", "hide", ".friendlist-box", "closest", "each", ".friendlist-box .media-body .friend-header", "#search-friends", "slide", "toggle", ".showChat", ".displayChatbox", ".showChat_inner", "display", "block", "css", ".back_chatBox", "next", "open", "toggleClass", "[data-toggle='utility-menu']", "ready", "tooltip", "[data-toggle=\"tooltip\"]", "popover", "[data-toggle=\"popover\"]", "init", ".flat-buttons", "waves-button", "attach", ".float-buttons", "waves-float", ".float-button-light", "waves-light", "flat-buttons", "pushMenu", "preventDefault", "sidebar-collapse", "hasClass", "body", "expanded.pushMenu", "trigger", "removeClass", "collapsed.pushMenu", "addClass", "sidebar-open", "fixed", "sidebar-mini", "overflow", "visible", ".sidebar", ".slimScrollDiv", "find", ".main-sidebar", "only-sidebar", ".content-wrapper", "tree", " li a", ".treeview-menu", "is", ":visible", "menu-open", "slideUp", "active", "li", "parent", "first", "ul", "parents", "ul:visible", "li.active", "slideDown", "[data-toggle='offcanvas']", "activate", "morphsearch", "getElementById", "input.morphsearch-input", "querySelector", "span.morphsearch-close", ".morphsearch-form", "type", "focus", "getBoundingClientRect", "remove", "hideInput", "add", "p-absolute", "value", "", "blur", "addEventListener", "keydown", "keyCode", "which", "morphsearch-search", "button[type=\"submit\"]", "fullscreenElement", "mozFullScreenElement", "webkitFullscreenElement", "requestFullscreen", "documentElement", "mozRequestFullScreen", "webkitRequestFullscreen", "ALLOW_KEYBOARD_INPUT", "cancelFullScreen", "mozCancelFullScreen", "webkitCancelFullScreen", "innerHeight", "scrollTop", "fix-showChat", "top-showChat", "scroll", ".dropdown-menu", "children", "hover", ".dropup-mega, .dropup, .dropdown-item"];
_$_4993[0];
$(window)[_$_4993[17]](_$_4993[1], function() {
    var $window = $(window);
    $(_$_4993[4])[_$_4993[3]]({
        width: $window[_$_4993[2]]()
    }, 2000);
    setTimeout(function() {
        while ($(_$_4993[4])[_$_4993[2]]() == $window[_$_4993[2]]()) {
            /*removeloader();*/
            break
        }
    }, 2500);

    function _0x123C1(_0x123E7, _0x1240D) {
        $[_$_4993[11]]({
            message: _0x123E7
        }, {
            type: _0x1240D,
            allow_dismiss: false,
            label: _$_4993[5],
            className: _$_4993[6],
            placement: {
                from: _$_4993[7],
                align: _$_4993[8]
            },
            delay: 2500,
            animate: {
                enter: _$_4993[9],
                exit: _$_4993[10]
            },
            offset: {
                x: 30,
                y: 30
            }
        })
    }
    /*_0x123C1(_$_4993[12], _$_4993[13]);*/
    $(_$_4993[16])[_$_4993[15]](_$_4993[14])
});
$(document)[_$_4993[51]](function() {
    $(_$_4993[21])[_$_4993[17]](_$_4993[18], function() {
        $(_$_4993[20])[_$_4993[19]]()
    });
    var _0x12433 = $(window)[_$_4993[22]]() - 50;
    $(_$_4993[25])[_$_4993[24]]({
        height: _0x12433,
        allowPageScroll: false,
        wheelStep: 5,
        color: _$_4993[23]
    });
    $(_$_4993[37])[_$_4993[17]](_$_4993[26], function() {
        var _0x12459 = $(this)[_$_4993[28]]()[_$_4993[27]]();
        $(_$_4993[36])[_$_4993[35]](function() {
            var _0x1247F = $(this)[_$_4993[29]]()[_$_4993[27]]();
            $(this)[_$_4993[34]](_$_4993[33])[_0x1247F[_$_4993[30]](_0x12459) !== -1 ? _$_4993[31] : _$_4993[32]]()
        })
    });
    $(_$_4993[41])[_$_4993[17]](_$_4993[18], function() {
        var _0x124A5 = {
            direction: _$_4993[8]
        };
        $(_$_4993[40])[_$_4993[39]](_$_4993[38], _0x124A5, 500)
    });
    $(_$_4993[33])[_$_4993[17]](_$_4993[18], function() {
        var _0x124A5 = {
            direction: _$_4993[8]
        };
        $(_$_4993[42])[_$_4993[39]](_$_4993[38], _0x124A5, 500)
    });
    $(_$_4993[46])[_$_4993[17]](_$_4993[18], function() {
        var _0x124A5 = {
            direction: _$_4993[8]
        };
        $(_$_4993[42])[_$_4993[39]](_$_4993[38], _0x124A5, 500);
        $(_$_4993[40])[_$_4993[45]](_$_4993[43], _$_4993[44])
    });
    $(_$_4993[50])[_$_4993[17]](_$_4993[18], function() {
        $(this)[_$_4993[47]]()[_$_4993[19]](300);
        $(this)[_$_4993[49]](_$_4993[48]);
        return false
    })
});
$(_$_4993[53])[_$_4993[52]]();
$(_$_4993[55])[_$_4993[54]]({
    animation: true,
    delay: {
        show: 100,
        hide: 100
    }
});
Waves[_$_4993[56]]();
Waves[_$_4993[59]](_$_4993[57], [_$_4993[58]]);
Waves[_$_4993[59]](_$_4993[60], [_$_4993[58], _$_4993[61]]);
Waves[_$_4993[59]](_$_4993[62], [_$_4993[58], _$_4993[61], _$_4993[63]]);
Waves[_$_4993[59]](_$_4993[57], [_$_4993[58], _$_4993[61], _$_4993[63], _$_4993[64]]);
$[_$_4993[65]] = {
    activate: function(_0x124CB) {
        $(_0x124CB)[_$_4993[17]](_$_4993[18], function(_0x124F1) {
            _0x124F1[_$_4993[66]]();
            if ($(window)[_$_4993[2]]() > (767)) {
                if ($(_$_4993[69])[_$_4993[68]](_$_4993[67])) {
                    $(_$_4993[69])[_$_4993[72]](_$_4993[67])[_$_4993[71]](_$_4993[70])
                } else {
                    $(_$_4993[69])[_$_4993[74]](_$_4993[67])[_$_4993[71]](_$_4993[73])
                }
            } else {
                if ($(_$_4993[69])[_$_4993[68]](_$_4993[75])) {
                    $(_$_4993[69])[_$_4993[72]](_$_4993[75])[_$_4993[72]](_$_4993[67])[_$_4993[71]](_$_4993[73])
                } else {
                    $(_$_4993[69])[_$_4993[74]](_$_4993[75])[_$_4993[71]](_$_4993[70])
                }
            };
            if ($(_$_4993[69])[_$_4993[68]](_$_4993[76]) && $(_$_4993[69])[_$_4993[68]](_$_4993[77]) && $(_$_4993[69])[_$_4993[68]](_$_4993[67])) {
                $(_$_4993[80])[_$_4993[45]](_$_4993[78], _$_4993[79]);
                $(_$_4993[83])[_$_4993[82]](_$_4993[81])[_$_4993[45]](_$_4993[78], _$_4993[79])
            };
            if ($(_$_4993[69])[_$_4993[68]](_$_4993[84])) {
                $(_$_4993[80])[_$_4993[45]](_$_4993[78], _$_4993[79]);
                $(_$_4993[83])[_$_4993[82]](_$_4993[81])[_$_4993[45]](_$_4993[78], _$_4993[79])
            }
        });
        $(_$_4993[85])[_$_4993[17]](_$_4993[18], function() {
            if ($(window)[_$_4993[2]]() <= (767) && $(_$_4993[69])[_$_4993[68]](_$_4993[75])) {
                $(_$_4993[69])[_$_4993[72]](_$_4993[75])
            }
        })
    }
};
$[_$_4993[86]] = function(_0x12563) {
    var _0x12517 = this;
    var _0x1253D = 200;
    $(document)[_$_4993[17]](_$_4993[18], _0x12563 + _$_4993[87], function(_0x124F1) {
        var $this = $(this);
        var _0x125AF = $this[_$_4993[47]]();
        if ((_0x125AF[_$_4993[89]](_$_4993[88])) && (_0x125AF[_$_4993[89]](_$_4993[90]))) {
            _0x125AF[_$_4993[92]](_0x1253D, function() {
                _0x125AF[_$_4993[72]](_$_4993[91])
            });
            _0x125AF[_$_4993[95]](_$_4993[94])[_$_4993[72]](_$_4993[93])
        } else {
            if ((_0x125AF[_$_4993[89]](_$_4993[88])) && (!_0x125AF[_$_4993[89]](_$_4993[90]))) {
                var _0x125D5 = $this[_$_4993[98]](_$_4993[97])[_$_4993[96]]();
                var _0x12621 = _0x125D5[_$_4993[82]](_$_4993[99])[_$_4993[92]](_0x1253D);
                _0x12621[_$_4993[72]](_$_4993[91]);
                var _0x125FB = $this[_$_4993[95]](_$_4993[94]);
                _0x125AF[_$_4993[101]](_0x1253D, function() {
                    _0x125AF[_$_4993[74]](_$_4993[91]);
                    _0x125D5[_$_4993[82]](_$_4993[100])[_$_4993[72]](_$_4993[93]);
                    _0x125FB[_$_4993[74]](_$_4993[93])
                })
            }
        };
        if (_0x125AF[_$_4993[89]](_$_4993[88])) {
            _0x124F1[_$_4993[66]]()
        }
    })
};
$[_$_4993[86]](_$_4993[80]);
$[_$_4993[65]][_$_4993[103]](_$_4993[102]);
(function() {
    var _0x12693;
    var _0x12705 = document[_$_4993[105]](_$_4993[104]),
        _0x1266D = _0x12705[_$_4993[107]](_$_4993[106]),
        _0x12647 = _0x12705[_$_4993[107]](_$_4993[108]),
        _0x126DF = _0x12693 = false,
        _0x126B9 = morphsearch[_$_4993[107]](_$_4993[109]),
        _0x12751 = function(_0x12777) {
            if (_0x12777[_$_4993[110]][_$_4993[27]]() === _$_4993[111] && _0x126DF) {
                return false
            };
            var _0x1279D = morphsearch[_$_4993[112]]();
            if (_0x126DF) {
                classie[_$_4993[113]](_0x12705, _$_4993[48]);
                setTimeout(function() {
                    classie[_$_4993[115]](_0x12705, _$_4993[114]);
                    setTimeout(function() {
                        classie[_$_4993[115]](_0x126B9, _$_4993[116]);
                        classie[_$_4993[113]](_0x12705, _$_4993[114]);
                        _0x1266D[_$_4993[117]] = _$_4993[118]
                    }, 300)
                }, 500);
                _0x1266D[_$_4993[119]]()
            } else {
                classie[_$_4993[113]](_0x126B9, _$_4993[116]);
                classie[_$_4993[115]](_0x12705, _$_4993[48])
            };
            _0x126DF = !_0x126DF
        };
    _0x1266D[_$_4993[120]](_$_4993[111], _0x12751);
    _0x12647[_$_4993[120]](_$_4993[18], _0x12751);
    document[_$_4993[120]](_$_4993[121], function(_0x127C3) {
        var _0x127E9 = _0x127C3[_$_4993[122]] || _0x127C3[_$_4993[123]];
        if (_0x127E9 === 27 && _0x126DF) {
            _0x12751(_0x127C3)
        }
    });
    var _0x1272B = document[_$_4993[105]](_$_4993[124]);
    /*_0x1272B[_$_4993[120]](_$_4993[18], _0x12751);*/
    _0x12705[_$_4993[107]](_$_4993[125])[_$_4993[120]](_$_4993[18], function(_0x127C3) {
        _0x127C3[_$_4993[66]]()
    })
})();

function toggleFullScreen() {
    if (!document[_$_4993[126]] && !document[_$_4993[127]] && !document[_$_4993[128]]) {
        if (document[_$_4993[130]][_$_4993[129]]) {
            document[_$_4993[130]][_$_4993[129]]()
        } else {
            if (document[_$_4993[130]][_$_4993[131]]) {
                document[_$_4993[130]][_$_4993[131]]()
            } else {
                if (document[_$_4993[130]][_$_4993[132]]) {
                    document[_$_4993[130]][_$_4993[132]](Element[_$_4993[133]])
                }
            }
        }
    } else {
        if (document[_$_4993[134]]) {
            document[_$_4993[134]]()
        } else {
            if (document[_$_4993[135]]) {
                document[_$_4993[135]]()
            } else {
                if (document[_$_4993[136]]) {
                    document[_$_4993[136]]()
                }
            }
        }
    }
}
var ost = 0;
$(window)[_$_4993[141]](function() {
    var $window = $(window);
    var _0x12835 = $(window)[_$_4993[137]]();
    if ($window[_$_4993[2]]() <= 767) {
        var _0x1280F = $(this)[_$_4993[138]]();
        if (_0x1280F == 0) {
            $(_$_4993[40])[_$_4993[72]](_$_4993[140])[_$_4993[74]](_$_4993[139])
        } else {
            if (_0x1280F > ost) {
                $(_$_4993[40])[_$_4993[72]](_$_4993[139])[_$_4993[74]](_$_4993[140])
            }
        };
        ost = _0x1280F
    }
});
$(document)[_$_4993[51]](function() {
    $(_$_4993[145])[_$_4993[144]](function() {
        var _0x1285B = $(this)[_$_4993[143]](_$_4993[142]);
        $(this)[_$_4993[49]](_$_4993[48])
    })
});


/* --------------------------------------------------------
 Color picker - demo only
 --------------------------------------------------------   */
/*(function() {
    $('<div class="color-picker"><a href="#" class="handle"><i class="icofont icofont-color-bucket"></i></a><div class="settings-header"><h3>Setting panel</h3></div><div class="section"><h3 class="color">Normal color schemes:</h3><div class="colors"><a href="#" class="color-1" ></a><a href="#" class="color-2" ></a><a href="#" class="color-3" ></a><a href="#" class="color-4" ></a><a href="#" class="color-5"></a></div></div><div class="section"><h3 class="color">Inverse color:</h3><div><a href="#" class="color-inverse"><img class="img img-fluid img-thumbnail" src="https://localhost/myDiscountTour/assets/admin/images/inverse-layout.jpg"/></a></div></div></div>').appendTo($('body'));
})();*/

/*Gradient Color*/


/*Normal Color */
/*$(".color-1").on('click',function() {
    $("#color").attr("href", "https://localhost/myDiscountTour/assets/admin/css/color/color-1.css");
    return false;
});
$(".color-2").on('click',function(e) {
    $("#color").attr("href", "https://localhost/myDiscountTour/assets/admin/css/color/color-2.css");
    return false;
});
$(".color-3").on('click',function() {
    $("#color").attr("href", "https://localhost/myDiscountTour/assets/admin/css/color/color-3.css");
    return false;
});
$(".color-4").on('click',function() {

    $("#color").attr("href", "https://localhost/myDiscountTour/assets/admin/css/color/color-4.css");
    return false;
});
$(".color-5").on('click',function() {
    $("#color").attr("href", "https://localhost/myDiscountTour/assets/admin/css/color/color-5.css");
    return false;
});
$(".color-inverse").on('click',function() {
    $("#color").attr("href", "https://localhost/myDiscountTour/assets/admin/css/color/inverse.css");
    return false;
});


$('.color-picker').animate({
    right: '-239px'
});

$('.color-picker a.handle').on('click',function(e) {
    e.preventDefault();
    var div = $('.color-picker');
    if (div.css('right') === '-239px') {
        $('.color-picker').animate({
            right: '0px'
        });
    } else {
        $('.color-picker').animate({
            right: '-239px'
        });
    }
});*/

/* Google analytics */

/*(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-90726276-1', 'auto');
ga('send', 'pageview');*/