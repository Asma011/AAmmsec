"use strict";
$(document).ready(function(){
		$('.yourCountdownContainer').countdown({
			date: "23 mar,2017 15:03:26"
		});

		

});	